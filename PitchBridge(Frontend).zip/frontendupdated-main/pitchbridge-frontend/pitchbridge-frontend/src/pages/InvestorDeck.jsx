import React from "react";

const InvestorDeck = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Investor Deck</h1>
      <p>Coming soon...</p>
    </div>
  );
};

export default InvestorDeck;
