export default function AdminActivity() {
  return <div>Admin - Platform Activity</div>;
}
