export default function AdminUsers() {
  return <div>Admin - Manage Users</div>;
}
