export default function CreateStartup() {
  return <div>Create Startup Page</div>;
}
