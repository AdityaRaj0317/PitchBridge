// src/config.js
export const API_BASE_URL = "https://pitchbridge-backend.onrender.com";
